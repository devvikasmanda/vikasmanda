import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class inventoryLogin extends HttpServlet
{
	public void doGet(HttpServletRequest srq,HttpServletResponse srp) throws IOException,ServletException
	{
		PrintWriter out=srp.getWriter();
		
		String PW=srq.getParameter("pw");
		String UN=srq.getParameter("se");
		String user,pass;
                           	int flag=0;

		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:odbc:wsm","","");

		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select *  from wsmlogin2 ");
		while(rs.next())
                                    {
		user=rs.getString(1).toString();
		pass=rs.getString(2).toString();
		
		if(UN.equals(user)&&PW.equals(pass))
			flag=1;
		
		}
		
		if(flag==1)
		{		
		if(UN.equals("administrator"))
			srp.sendRedirect("http://localhost:7001/supermarket/reporthome.html");
		else
		                  srp.sendRedirect("http://localhost:7001/supermarket/inventoryhome.html");
				
		}
		else
		{
		srp.sendRedirect("http://localhost:7001/supermarket/invalid.html");
		}
	
		}
	

		catch(Exception e)
		{
			out.println("Exception caught : " +e);
		}

	}
}
