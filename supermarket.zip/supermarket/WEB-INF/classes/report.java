import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class report extends HttpServlet
{
	public void doGet(HttpServletRequest srq,HttpServletResponse srp) throws IOException,ServletException
	{
		PrintWriter out=srp.getWriter();
		String DATE=srq.getParameter("DATE");
		PreparedStatement ps = null;
		String TRANIDD="";
		String TOTALL="";
		






		
		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:odbc:wsm","","");

		ps  = con.prepareStatement("select TRANID,TOTAL  from  transaction where  DATE=? order by total");
		ps.setString(1,DATE);
		ps.executeQuery();
		ResultSet rs = ps.getResultSet();
out.println("<center><font style=verdhana color=#990099><b><u><h3>SEARCH RESULTS</h3></b><u></font></center>");
out.println("<a href=reporthome.html><b>Report Home</b></a></center>");

		while(rs.next())
		{
                        out.println("<body background=bg.jpg>");
		

	                 out.println("<table background=b1.jpg border=8 cellpadding=8 cellspacing=4 align=center width=600 height=200>");
		out.println("	<tr><td><b> BillDate </b></td>");

	                out.println(" <td><b>"+DATE+"<b></td></tr>");

	               out.println(" <tr><td><b>Transaction Id</b></td>");

	               out.println("<td><b>"+TRANIDD+"<b></td></tr>");

	               out.println("<tr><td><b>Total</b></td>");

                                 out.println("<td>" +TOTALL+"</td></tr>");	

	               

		
		out.println("<a href=index.html>Home</a>");

		out.println("</table><br>");
		
		TRANIDD= rs.getString("TRANID");
		TOTALL= rs.getString("TOTAL");
		
		
		}
		
		}
	

		catch(Exception e)
		{
			out.println("Exception caught : " +e);
		}
		
	}
}

