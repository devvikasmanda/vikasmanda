import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class report4 extends HttpServlet
{
	public void doGet(HttpServletRequest srq,HttpServletResponse srp) throws IOException,ServletException
	{
		PrintWriter out=srp.getWriter();
		String DATE=srq.getParameter("DATE");
		PreparedStatement ps = null;
		String ITEMIDD="";
		String ITEMTYPEE="";
		String ITEMNAMEE="";
String ITEMQUANTITYY="";
String ITEMPRICEE="";

		






		
		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:odbc:wsm","","");

		ps  = con.prepareStatement("select ITEMID,ITEMTYPE,ITEMNAME,ITEMQUANTITY,ITEMPRICE  from  item where  DATE=? order by ITEMPRICE");
		ps.setString(1,DATE);
		ps.executeQuery();
		ResultSet rs = ps.getResultSet();
out.println("<center><font style=verdhana color=#990099><b><u><h3>SEARCH RESULTS</h3></b><u></font></center>");
out.println("<a href=logout.html><b>logout</b></a></center>");

		while(rs.next())
		{
                        out.println("<body background=bg.jpg>");
		

	                 out.println("<table background=b1.jpg border=8 cellpadding=8 cellspacing=4 align=center width=600 height=200>");
		out.println("	<tr><td><b> Date </b></td>");

	                out.println(" <td><b>"+DATE+"<b></td></tr>");

	               out.println(" <tr><td><b>Item Id</b></td>");

	               out.println("<td><b>"+ITEMIDD+"<b></td></tr>");
out.println(" <tr><td><b>Type Of Item</b></td>");

	               out.println("<td><b>"+ITEMTYPEE+"<b></td></tr>");

	               out.println("<tr><td><b>ITEM NAME</b></td>");

                                 out.println("<td>" +ITEMNAMEE+"</td></tr>");	

	               out.println("<tr><td><b>ITEM QUANTITY</b></td>");

                                 out.println("<td>" +ITEMQUANTITYY+"</td></tr>");	
out.println("<tr><td><b>ITEM NAME</b></td>");

                                 out.println("<td>" +ITEMPRICEE+"</td></tr>");	

		
		out.println("<a href=index.html>Home</a>");

		out.println("</table><br>");
		
		ITEMIDD= rs.getString("ITEMID");
		ITEMTYPEE= rs.getString("ITEMTYPE");
		ITEMNAMEE= rs.getString("ITEMNAME");
ITEMQUANTITYY= rs.getString("ITEMQUANTITY");
ITEMPRICEE= rs.getString("ITEMPRICE");
		
		
		}
		
		}
	

		catch(Exception e)
		{
			out.println("Exception caught : " +e);
		}
		
	}
}

