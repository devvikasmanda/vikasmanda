import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class transaction extends HttpServlet
{
	public void doGet(HttpServletRequest srq,HttpServletResponse srp) throws IOException,ServletException
	{
		PrintWriter out=srp.getWriter();
		String TRANID=srq.getParameter("TRANID");
		String CASHIER=srq.getParameter("CASHIER");
		String ITEMID=srq.getParameter("ITEMID");
		String ITEMNAME=srq.getParameter("ITEMNAME");
		String ITEMQUANTITY=srq.getParameter("ITEMQUANTITY");
		String ITEMPRICE=srq.getParameter("ITEMPRICE");
		String DATE=srq.getParameter("DATE");
		String TOTAL=srq.getParameter("TOTAL");
		
		

		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:odbc:wsm","","");

		PreparedStatement ps=con.prepareStatement("insert into  transaction  values(?,?,?,?,?,?,?,?);");
		ps.setString(1,TRANID); ps.setString(2,CASHIER); ps.setString(3,ITEMID); ps.setString(4,ITEMNAME);
ps.setString(5,ITEMQUANTITY); ps.setString(6,ITEMPRICE); ps.setString(7,DATE); ps.setString(8,TOTAL); 
	int n = ps.executeUpdate();
		
		if(n==1)
		{
		out.println("<html>");
		out.println("<body background=bg.jpg>");
		
		out.println("<a href=cashorcredit.html><center>Click for The Payment</center></a>");
		}
		else
		{
		out.println("<html>");
		out.println("<body>");
		out.println("<center><b> PAYMENT IS FAILED !!<b></center>");
		out.println("<a href=home.html>HOME</a></center>");
		}

		}
		
		catch(Exception e)
		{
			out.println("Exception caught : " +e);
		}

	}
}


		
		

